# Homework2_Part1
