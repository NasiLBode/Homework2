﻿// Homework No. 2 Exercise No. 1
// File Name: Homework2_Part1
// @author: Nasi Bode
// Date: 01 September 2023
//
// Problem Statement:
//
// Overall Plan:
// 1. Print welcome message to the screen
// 2. Create a list to hold the pig latin name in
// 3. Get user input containing the name
// 4. Split the words in the string, seperated by a ' ' space
// 5. use a foreach statement to apply the pig latin rules to each word
// 6. Find the first letter of the name
// 7. Find the rest of the lettes in the name
// 8. Create a new variable to hold the capitalized version of the rest of
// the letters
// 9. Save the word to the list created
// 10. Print the new pig latin name to the screen



//import necessary packages
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//create main class and objects needed to implement tasks
namespace Homework2_Part1
{
    class Program
    {
        public static void Main(string[] args)
        {
            //print welcoming message to the screen
            Console.WriteLine("Welcome! This program will translate your first and last name into Pig Latin!");
            Console.WriteLine("Enter your name here: ");

            //create a list to hold the new name string
            List<string> newName = new List<string>();

            //get input from the user
            //create an array to hold the sentence information
            string userInput = Console.ReadLine();
            //split the words up, if in a sentence
            string[] words = userInput.ToLower().Split(' ');

            //use a foreach statement to cycle through the words in the name
            foreach (string word in words)
            {
                //find the first letter of the word
                string firstLetter = word.Substring(0, 1);
                //find the rest of the word string
                string restOfWord = word.Substring(1, word.Length - 1);
                //captialize the first word in each string
                //assign to new string variable
                string capitalRestOfWord = char.ToUpper(restOfWord[0]) + restOfWord.Substring(1);

                //add the new word to the list created
                newName.Add(capitalRestOfWord + firstLetter + "ay");
               
            }

            //join all the newName words together to make one final string
            string finalName = string.Join(" ", newName);
            //print result to the screen
            Console.WriteLine(finalName);
           

        }
    }
}
